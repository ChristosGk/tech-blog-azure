
const HomePage = () => (
    <>
    <h1>Tech blog | ReloadSearch</h1>
    <p>
        Welcome to ReloadSearch
    </p>
    <p>
        Donec vel mauris lectus. Etiam nec lectus urna. Sed sodales ultrices dapibus. 
        Nam blandit tristique risus, eget accumsan nisl interdum eu. 
    </p>
    <p>
        Etiam nec lectus urna. Sed sodales ultrices dapibus. 
        Nam blandit tristique risus, eget accumsan nisl interdum eu. 
    </p>
    </>
);

export default HomePage;