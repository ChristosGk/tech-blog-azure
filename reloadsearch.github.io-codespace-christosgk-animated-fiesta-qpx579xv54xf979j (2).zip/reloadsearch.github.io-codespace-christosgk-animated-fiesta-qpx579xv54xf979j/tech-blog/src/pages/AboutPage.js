const AboutPage = () => {
    return (
        <>
        <h1>About ReloadSearch</h1>
        <p>
            Welcome to ReloadSearch
            ligula id risus posuere, vel eleifend ex egestas. Sed in turpis leo. 
            Aliquam malesuada in massa tincidunt egestas.
        </p>
        <p>
            Donec vel mauris lectus. Etiam nec lectus urna. Sed sodales ultrices dapibus. 
            Nam blandit tristique risus, eget accumsan nisl interdum eu.
        </p>
        <p>
            Etiam nec lectus urna. Sed sodales ultrices dapibus. 
            Nam blandit tristique risus, eget accumsan nisl interdum eu.
        </p>
    </>
    );
}

export default AboutPage;